const section = document.getElementById('detailsPage');

export function showDetails(context) {
    context.showSection(section);
}