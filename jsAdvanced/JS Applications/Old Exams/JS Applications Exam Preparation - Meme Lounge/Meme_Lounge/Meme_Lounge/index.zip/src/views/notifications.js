function makeNotificationElement(message) {
    const section = document.createElement('section');
    section.id = 'notifications';
    section.innerHTML = `
    <div id="errorBox" class="notification">
        <span>${message}</span>
    </div>`;

    return section;
}

export function notify(message) {
    const notificationEl = makeNotificationElement(message);
    notificationEl.querySelector('.notification').style.display = 'block';
    document.getElementById('container').appendChild(notificationEl);

    setTimeout(() => notificationEl.remove(), 3000);
}
