Resolution: 1920x1080
Scale: 125%